export const TOKEN_SECRET = 'secret123$';
export const TOKEN_NAME = 'MyToken';
export const USER_NAME = 'Usuario';

export const BASE_URL = 'https://pokeapi.co/api/v2/'
export const GET_100_POKEMONS = 'pokemon?limit=100&offset=0'
export const PAGINATION_SIZE = 10;